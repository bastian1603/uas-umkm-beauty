<title>Our Products</title>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('style/product_list.css')); ?>">


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    
   
</head>
<body>

  <div class="container mt-5">
        <h1>Product List</h1>

  <table id="product" class="table table-striped" style="width:100%">
          <thead>
              <tr>
              <th>#</th>
              <th>Product Name</th>
              <th>Price</th>
              <th>Brand</th>
              <th>Category</th>
              <th>Pic</th>
              <th>Action</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($loop->iteration); ?></td>
                      <td><?php echo e($product->product_name); ?></td>
                      <td><?php echo e($product->price); ?></td>
                      <td><?php echo e($product->brand->brand_name); ?></td>
                      <td><?php echo e($product->category->category_name); ?></td>
                      <td><img src="<?php echo e($product->product_pic); ?>" alt="<?php echo e($product->product_name); ?>" width="100px"></td>
                      
                      <td>
                      <a href="/edit/<?php echo e($product->id); ?>" class="btn btn-success">Edit</a>
                        <form action="/delete/<?php echo e($product->id); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                      </td>

              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      
        
      </table>
    </div>
  

  <div class="container mt-5">
        <h1>Category List</h1>

  <table id="category" class="table table-striped" style="width:100%">
          <thead>
              <tr>
              <th>#</th>
              <th>Category name</th>
              <th>Action</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($category->category_name); ?></td>  
              <td>
                    <a href="/edit_category_brand/category/<?php echo e($category->id); ?>" class="btn btn-success">Edit</a>
                      <form action="/deleting/category/<?php echo e($category->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                      </form>
                    </td>

              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      
        
      </table>
    </div>


  <div class="container mt-5">
        <h1>Brand List</h1>

  <table id="brand" class="table table-striped" style="width:100%">
          <thead>
              <tr>
              <th>#</th>
              <th>Brand name</th>
              <th>Action</th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($brand->brand_name); ?></td>  
                    <td>
                    <a href="/edit_category_brand/brand/<?php echo e($brand->id); ?>" class="btn btn-success">Edit</a>
                      <form action="/deleting/brand/<?php echo e($brand->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                      </form>
                    </td>

              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      
        
      </table>
    </div>
  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<!-- Bootstrap Bundle JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>


<script> 
            $(document).ready(function(){
                $('#product').DataTable();
            })

            $(document).ready(function(){
                $('#brand').DataTable();
            })

            $(document).ready(function(){
                $('#category').DataTable();
            })
</script>
</body>
</html>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\latihan2laravel\resources\views/admin_crud/product_list.blade.php ENDPATH**/ ?>