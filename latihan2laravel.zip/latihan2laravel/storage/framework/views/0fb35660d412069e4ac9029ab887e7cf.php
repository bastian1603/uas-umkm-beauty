<?php $__env->startSection('body'); ?>
<body onload="load()">
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <div class="col-10 search-box">
        <form action="">
            <input onchange="return_data()" type="text" name="search_input" id="search_input">
            <button type="submit">Search</button>
        </form>
    </div>

    <!-- Shop Section Begin -->
    <section class="shop spad">

        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="shop__sidebar">
                        <div class="sidebar__categories">
                            <div class="section-title">
                                <h4>Filtering</h4>
                            </div>
                            <form class="categories__accordion">
                                <div class="accordion" id="accordionExample">
                                    
                                    <div class="card">
                                        <div class="card-heading">
                                            <a data-toggle="collapse" data-target="#collapseTwo">by Brand</a>
                                        </div>
                                        <div id="collapseTwo" class="collapse" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <ul class="ls-no">

                                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li loading="lazy" >
                                                    <a href="/catalogue?brand=<?php echo e($brand->id); ?>">    
                                                        <?php echo e($brand->brand_name); ?>

                                                    </a>
                                                    </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card">
                                        <div class="card-heading">
                                            <a data-toggle="collapse" data-target="#collapseThree">by Category</a>
                                        </div>
                                        <div id="collapseThree" class="collapse" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <ul class="ls-no">
                                                   
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li >
                                                            <a href="/catalogue?category=<?php echo e($category->id); ?>">
                                                            <?php echo e($category->category_name); ?>

                                                            </a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                     
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
                <div class="col-lg-9 col-md-9">
                    <div class="row products-box" id="product_list">

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mix women more-mrgin">
            <div class="product__item">
                <div class="product__item__pic set-bg">
                    <img src="<?php echo e($product->product_pic); ?>" alt="<?php echo e($product->product_name); ?>">
                    <ul class="product__hover">
                        <li onclick="insert('<?php echo e($product->id); ?>', '<?php echo e(addslashes($product->product_name)); ?>', '<?php echo e(addslashes($product->product_pic)); ?>', parseInt('<?php echo e($product->price); ?>'))">
                            <span><span class="icon_bag_alt"></span></span>
                        </li>
                    </ul>
                </div>
                <div class="product__item__text">
                    <h6><a href="#"><?php echo e($product->product_name); ?></a></h6>
                    <div class="product__price"><?php echo 'IDR ' . number_format($product->price, 2, '.', ','); ?></div>
                </div>
            </div>
        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                  
                </div>
            </div>
            <div class="row">
            <div class="col-lg-5">
                </div>
                <div class="col-lg-5">
                <?php echo e($products->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
            <div class="col-lg-5">
                </div>
        </div>
    </section>
    <!-- Shop Section End -->



</body>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\latihan2laravel\resources\views\customer_ui\shop.blade.php ENDPATH**/ ?>