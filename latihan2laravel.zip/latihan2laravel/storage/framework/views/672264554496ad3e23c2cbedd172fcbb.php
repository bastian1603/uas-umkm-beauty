<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Lj Beauty | <?php echo e($title); ?></title>
    <link rel="icon" type="image/x-icon" href="/image/favicon.ico">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Cookie&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap"
    rel="stylesheet">


    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>
<body onload="load()">
 
<!-- Offcanvas Menu Begin -->
<div aria-live="polite" aria-atomic="true" style="bottom:20px; right: 20px; position: fixed; min-height: 200px; z-index:2">
    <!-- Container untuk menampilkan toast -->
    <div id="toast_container" style="position: absolute; top: 0px; right: 0px;"></div>
</div>


<div class="offcanvas-menu-overlay"></div>
    <div class="offcanvas-menu-wrapper">
        <div class="offcanvas__close">+</div>
       
        <div class="offcanvas__logo">
            <a href="/"><img src="image/logo lj beauty house.png" alt=""></a>
        </div>
        <div id="mobile-menu-wrap"></div>

    </div>
    <!-- Offcanvas Menu End -->

    <!-- Header Section Begin -->
    <header class="header">
        <div class="container-fluid">
            <div class="row center">
                <div class="col-xl-3 col-lg-2 mid">
                    <div class="header__logo">
                        <a href="/"><img src="image/logo lj beauty house.png" alt="" width="77px"> <span style="font-size: 20px; color:black;">| Lj Beauty</Span></a>
                    </div>
                </div>
                
                <div class="col-xl-5 col-lg-4">
                 
                </div>
                <div class="col-lg-4">

                        <nav class="header__menu">
                            <ul>
                                <li class="<?php echo e($title === 'Home'? 'active' : ''); ?>"><a href="/">Home</a></li>
                                <li class="<?php echo e($title === 'Catalogue'? 'active' : ''); ?>"><a href="/catalogue">Catalogue</a></li>
                                <li class="<?php echo e($title === 'Cart'? 'active' : ''); ?>"><a href="/cart">Cart</a></li>
                                <li class="<?php echo e($title === 'Contact Us'? 'active' : ''); ?>"><a href="/contact">Contact Us</a></li>
                            </ul>
                        </nav>
                        
                </div>
            </div>
            <div class="canvas__open">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </header>
    <!-- Header Section End -->

        <?php echo $__env->yieldContent('body'); ?>
        <!-- Instagram Begin -->
        <div class="instagram">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                        <a href="https://www.instagram.com/ljbeautyhouse/"><div class="instagram__item set-bg" data-setbg="img/instagram/insta1.jpg">
                            <div class="instagram__text">
                                <i class="fa fa-instagram"></i>
                                <span>@ ljbeautyhouse</span>
                            </div>
                        </div></a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                        <a href="https://www.instagram.com/ljbeautyhouse/"><div class="instagram__item set-bg" data-setbg="img/instagram/insta2.jpg">
                            <div class="instagram__text">
                                <i class="fa fa-instagram"></i>
                                <span>@ ljbeautyhouse</span>
                            </div>
                        </div></a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                        <a href="https://www.instagram.com/ljbeautyhouse/"><div class="instagram__item set-bg" data-setbg="img/instagram/insta3.jpg">
                            <div class="instagram__text">
                                <i class="fa fa-instagram"></i>
                                <span>@ ljbeautyhouse</span>
                            </div>
                        </div></a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                        <a href="https://www.instagram.com/ljbeautyhouse/"><div class="instagram__item set-bg" data-setbg="img/instagram/insta4.jpg">
                            <div class="instagram__text">
                                <i class="fa fa-instagram"></i>
                                <span>@ ljbeautyhouse</span>
                            </div>
                        </div></a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                        <a href="https://www.instagram.com/ljbeautyhouse/"><div class="instagram__item set-bg" data-setbg="img/instagram/insta5.jpg">
                            <div class="instagram__text">
                                <i class="fa fa-instagram"></i>
                                <span>@ ljbeautyhouse</span>
                            </div>
                        </div></a>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-4 p-0">
                        <a href="https://www.instagram.com/ljbeautyhouse/"><div class="instagram__item set-bg" data-setbg="img/instagram/insta6.jpg">
                            <div class="instagram__text">
                                <i class="fa fa-instagram"></i>
                                <span>@ ljbeautyhouse</span>
                            </div>
                        </div></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Instagram End -->

        <!-- Footer Section Begin -->
        <footer>
        <div class="footer-container" >
            <div class="footer-logo">
                <h2>LJ Beauty House</h2>
            </div>
            <div class="footer-desc">
                <ul>
                    <h3>Product</h3>
                    <li><a>Pricing</a></li>
                    <li><a>Customer Stories</a></li>
                </ul>
                <ul>
                    <h3>Resources</h3>
                    <li><a>Blog</a></li>
                    <li><a>Guide & Tutorials</a></li>
                    <li><a>Help</a></li>
                </ul>
                <ul>
                    <h3>Company</h3>
                    <li><a>Media Kit</a></li>
                    <li><a>Careers</a></li>
                </ul>
            </div>
            <div class="footer-links">
                <a href="https://wa.me/6282362052767" target="_blank">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp">
                </a>
                <a href="https://www.instagram.com/ljbeautyhouse/" target="_blank">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/a/a5/Instagram_icon.png" alt="Instagram">
                </a>
                <a href="https://www.instagram.com/yourinstagramlink" target="_blank">
                    <img src="https://freepnglogo.com/images/all_img/1697562980facebook-logo-transparent.png" alt="Facebook">
                </a>
            </div>
            <div class="footer-copyright mid">
                <p>&copy; 2024 LJ Beauty House. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->

    <!-- Search Begin -->
    <div class="search-model">
        <div class="h-100 d-flex align-items-center justify-content-center">
            <div class="search-close-switch">+</div>
            <form class="search-model-form">
                <input type="text" id="search-input" placeholder="Search here.....">
            </form>
        </div>
    </div>
        <!-- Search End -->




    <!-- Js Plugins -->

    <script src="js/cart.js" type="text/javascript"></script>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/main.js"></script>
    

</body>
</html><?php /**PATH C:\laragon\www\latihan2laravel\resources\views\layouts\header-footer.blade.php ENDPATH**/ ?>