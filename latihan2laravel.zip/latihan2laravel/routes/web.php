<?php

use App\Http\Controllers\ProductsListController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\User;
use Illuminate\Support\Facades\Route;

//* Customer Routing Function

Route::get('/', [App\Http\Controllers\User::class, 'route_home']);

Route::get('/cart', [App\Http\Controllers\User::class, 'route_cart']);

Route::get('/contact', [App\Http\Controllers\User::class, 'route_contact']);

Route::get('/get_data', [App\Http\Controllers\User::class, 'get_data'])->name('get_data');

Route::get('/home', [App\Http\Controllers\User::class, 'route_c_home']);

Route::get('/catalogue', [App\Http\Controllers\User::class, 'route_catalogue']);

Route::get('/search', [App\Http\Controllers\User::class, 'get_search_data']);

//* routing original from laravel

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {

    //* Admin Routing function

    Route::get('/admin', [App\Http\Controllers\ProductsListController::class, 'route_product_list']);

    Route::get('/create', [App\Http\Controllers\ProductsListController::class, 'route_create']);

    Route::get('/edit/{id}', [App\Http\Controllers\ProductsListController::class, 'route_edit']);

    Route::get('/insert_brand_category', [App\Http\Controllers\ProductsListController::class, 'route_add_brand_category']);

    Route::get('/edit_category_brand/{type}/{id}', [App\Http\Controllers\ProductsListController::class, 'route_edit_brand_category']); 

    Route::get('/excel_insert', [App\Http\Controllers\ProductsListController::class, 'route_special_insert']);

    Route::get('/insert_carousel', [App\Http\Controllers\ProductsListController::class, 'route_insert_carousel']);

    Route::get('/edit_carousel', [App\Http\Controllers\ProductsListController::class, 'route_edit_carousel']);

    Route::get('/register', function(){
        return view('auth.register');
    });


    //* all function for CRUD-ing database

    Route::patch('/update/{id}', [App\Http\Controllers\ProductsListController::class, 'update']);

    Route::post('/storing', [App\Http\Controllers\ProductsListController::class, 'store']);

    Route::delete('/delete/{ixdd}', [App\Http\Controllers\ProductsListController::class, 'delete']);

    Route::post('/add_brand_category', [App\Http\Controllers\ProductsListController::class, 'add_brand_category']);

    Route::patch('/editing_brand_category/{type}/{id}', [App\Http\Controllers\ProductsListController::class, 'edit_brand_category']);

    Route::delete('deleting/{type}/{id}', [App\Http\Controllers\ProductsListController::class, 'delete_brand_category']);

    Route::post('/insert_excel', [App\Http\Controllers\ProductsListController::class, 'accessing_excel']);


    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
