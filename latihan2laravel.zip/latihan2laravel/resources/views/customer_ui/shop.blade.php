@extends('layouts.header-footer')

@section('body')
<body onload="load()">
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <div class="col-10 search-box">
        <form action="">
            <input onchange="return_data()" type="text" name="search_input" id="search_input">
            <button type="submit">Search</button>
        </form>
    </div>

    <!-- Shop Section Begin -->
    <section class="shop spad">

        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <div class="shop__sidebar">
                        <div class="sidebar__categories">
                            <div class="section-title">
                                <h4>Filtering</h4>
                            </div>
                            <form class="categories__accordion">
                                <div class="accordion" id="accordionExample">
                                    
                                    <div class="card">
                                        <div class="card-heading">
                                            <a data-toggle="collapse" data-target="#collapseTwo">by Brand</a>
                                        </div>
                                        <div id="collapseTwo" class="collapse" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <ul class="ls-no">

                                                    @foreach($brands as $brand)
                                                    <li loading="lazy" >
                                                    <a href="/catalogue?brand={{ $brand->id }}">    
                                                        {{ $brand->brand_name }}
                                                    </a>
                                                    </li>
                                                    @endforeach

                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="card">
                                        <div class="card-heading">
                                            <a data-toggle="collapse" data-target="#collapseThree">by Category</a>
                                        </div>
                                        <div id="collapseThree" class="collapse" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <ul class="ls-no">
                                                   
                                                    @foreach($categories as $category)
                                                        <li >
                                                            <a href="/catalogue?category={{ $category->id }}">
                                                            {{ $category->category_name }}
                                                            </a>
                                                        </li>
                                                    @endforeach   

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                     
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
                <div class="col-lg-9 col-md-9">
                    <div class="row products-box" id="product_list">

                        @foreach($products as $product)
                        <div class="col-lg-3 col-md-4 col-sm-6 mix women more-mrgin">
            <div class="product__item">
                <div class="product__item__pic set-bg">
                    <img src="{{ $product->product_pic }}" alt="{{ $product->product_name }}">
                    <ul class="product__hover">
                        <li onclick="insert('{{$product->id }}', '{{ addslashes($product->product_name) }}', '{{ addslashes($product->product_pic) }}', parseInt('{{ $product->price }}'))">
                            <span><span class="icon_bag_alt"></span></span>
                        </li>
                    </ul>
                </div>
                <div class="product__item__text">
                    <h6><a href="#">{{ $product->product_name }}</a></h6>
                    <div class="product__price">@price( $product->price )</div>
                </div>
            </div>
        </div>

                        @endforeach

                    </div>
                  
                </div>
            </div>
            <div class="row">
            <div class="col-lg-5">
                </div>
                <div class="col-lg-5">
                {{ $products->links('pagination::bootstrap-4') }}
                </div>
            </div>
            <div class="col-lg-5">
                </div>
        </div>
    </section>
    <!-- Shop Section End -->



</body>

@endsection