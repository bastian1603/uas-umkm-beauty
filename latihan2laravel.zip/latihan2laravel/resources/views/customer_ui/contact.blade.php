@extends('layouts.header-footer')

@section('body')

<body>
    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

    <!-- Contact Section Begin -->
    <section class="contact spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="contact__content">
                        <div class="contact__address">
                            <h5>Contact info</h5>
                            <ul>
                                <li>
                                    <h6><i class="fa fa-map-marker"></i> Address</h6>
                                    <p>Tg, Blk. Z1, Bukit Ayu Lestari, No 97, Tj. Piayu, Kota Batam, Kepulauan Riau 29437</p>
                                </li>
                                <li>
                                    <h6><i class="fa fa-phone"></i> Phone</h6>
                                    <p><span>+62 813-7203-7663</span></p>
                                </li>
                                <li>
                                    <h6><i class="fa fa-headphones"></i> Support</h6>
                                    <p>Ljbeautyhouse@gmail.com</p>
                                </li>
                            </ul>
                        </div>
                        <div class="contact__form">
                            <h5>SEND MESSAGE</h5>
                            <form>
                                <input type="text" placeholder="Name" id="name" required>
                                <input type="text" placeholder="Email" id="email" required>
                                <textarea placeholder="Message" id="pesan" required></textarea>
                                <button onclick="send_to_whatsapp()" type="submit" class="site-btn">Send Message</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="contact__map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1919.2277061200878!2d104.00080133401427!3d1.048245991591577!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31d98d1a02ee7635%3A0x5e6918f4c85d9e49!2sLj%20Beauty%20House!5e0!3m2!1sid!2sid!4v1718032613032!5m2!1sid!2sid" 
                        width="600" height="780" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                    </iframe>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Contact Section End -->

</body>

@endsection