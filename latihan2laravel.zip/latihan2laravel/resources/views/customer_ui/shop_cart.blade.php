
<title>LjBeauty | Cart</title>
@extends('layouts.header-footer')



@section('body')
<section class="shop-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="shop__cart__table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="cart_container">
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <form action="#" class="checkout__form">
                <div class="row">
                    <div class="col-lg-12 more-mrgin">
                        <h5>Billing detail</h5>
                        <div class="row">
                            <div class="col-lg-6">

                                <div class="checkout__form__input">
                                    <label for="name"><p>Name <span>*</span></p></label>
                                    <input type="text" id="nama_penerima" placeholder="Masukkan nama penerima" required>
                                </div>
                                <div class="checkout__form__input">
                                    <label for="phone_number"><p>No. WhatsApp <span>*</span></p></label>
                                    <input type="number" id="no_hp_penerima" placeholder="Masukkan no. whatsapp (Cth : 0812 1233 1233)" required>
                                </div>
                                <div class="checkout__form__input">
                                    <label for=""><p>Cara Pembayaran <span>*</span></p></label>
                                </div>
                            
                                    <div class="radio-cart ">
                                        <input type="radio" id="cod" name="pembayaran" value="cod"><label for="cod" >COD</label>
                                    </div>
                                    <div class="radio-cart">
                                        <input type="radio" id="transfer" name="pembayaran" value="transfer"><label for="transfer">Transfer</label>
                                    </div>
                 
                                <div class="checkout__form__input">
                                    <label for="alamat"><p>Address <span>*</span></p></label>
                                    <input type="textarea" id="address" placeholder="Masukkan alamat tujuan pengiriman" required>

                                    <div class="checkout__form__input">
                                        <p>Order notes </p>
                                        <input type="text"
                                        placeholder="Note about your order, e.g, special noe for delivery" id="note">
                                    </div>
                                </div>
                            </div>
                    
                        <div class="col-lg-6 justify-contend-end">
                            <div class="checkout__order">
                                <h5>Your order</h5>
                                <div class="checkout__order__product" >
                                    <ul id="daftar_cart">
                                    </ul>
                                </div>
                                <div class="checkout__order__total">
                                    <ul>
                                        <li>Total <span id="total"></span></li>
                                    </ul>
                                </div>
                                <button class="site-btn" onclick="cart.to_wa()">Memesan Online</button>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
                </form>
            <section>
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="cart__btn">
                        <a href="/catalogue">Continue Shopping</a>
                    </div>
                </div>
               
            </div>

        </div>
    </section>
    <!-- Shop Cart Section End -->

    @endsection