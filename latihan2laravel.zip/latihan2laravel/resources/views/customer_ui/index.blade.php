<title>LjBeauty | Home</title>

@extends('layouts.header-footer')


@section('body')

    <!-- Page Preloder -->
    <div id="preloder">
        <div class="loader"></div>
    </div>

  <!-- Categories Section Begin -->
  <section class="categories">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    <div class="col-lg-12 p-0 d-flex positioning">
                        <div class="categories__item categories__large__item set-bg set-bg-2" data-setbg="img/foto.jpg" style="height: 500px;">
                            <div class="categories__text">
                                
                                <h1 style="color: white;" class="text-rose 100"> Revitalize your skin
                                revive your soul</h1>
                                <a href="/catalogue" style="color: white;">Shop now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<!-- Categories Section End -->


<!-- Product Section Begin -->
<section class="product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 col-md-5">
            </div>
            <div class="col-lg-5 col-md-5">
                <div class="section-title">
                    <h4>Our Products</h4>
                </div>
            </div>
            <div class="col-lg-5 col-md-5">
            </div>
        </div>
        <div class="row property__gallery">

            
        @foreach($products as $product) 
        <div class="col-lg-3 col-md-4 col-sm-6 mix women more-mrgin">
            <div class="product__item" 
                data-id="{{ $product->id }}" 
                data-name="{{ addslashes($product->product_name) }}" 
                data-pic="{{ addslashes($product->product_pic) }}" 
                data-price="{{ $product->price }}">
                <div class="product__item__pic set-bg">
                    <img src="{{ $product->product_pic }}" alt="{{ $product->product_name }}">
                    <ul class="product__hover">
                        <li onclick="insert('{{$product->id }}', '{{ addslashes($product->product_name) }}', '{{ addslashes($product->product_pic) }}', parseInt('{{ $product->price }}'))">
                            <span class="icon_bag_alt"></span>
                        </li>
                    </ul>
                </div>
                <div class="product__item__text">
                    <h6><a href="#">{{ $product->product_name }}</a></h6>
                    <div class="product__price">@price( $product->price )</div>
                </div>
            </div>
        </div>


        @endforeach

        </div>
    </div>
</section>
<!-- Product Section End -->

<br>
<hr>

<!-- Discount Section Begin -->
<section class="discount">

    <div class="col-12 mid more-mrgin">
        <h2>About Us</h2>
    </div>
    <div class="container mid">
        <div class="row mid more-mrgin">
            <div class="col">
   
                <img class="box-about-us" style="width: 18rem;" src="image/WhatsApp Image 2024-05-01 at 21.45.26.jpeg" class="card-img-top" alt="...">
            </div>
            <div class="col">
                <img class="box-about-us" style="width: 18rem;" src="image/WhatsApp Image 2024-02-25 at 22.02.00_f2cc5458.jpg" class="card-img-top" alt="...">

            </div>
        </div>
    </div>
    <div class="col-12 mid more-mrgin">
    <div class="col-lg-7 col-md-8 mid ali-cnt">
    LJ Beauty House is a skincare shop offering a curated selection of high-quality products from various trusted brands. We provide everything from hydrating moisturizers and rejuvenating serums to gentle cleansers and protective sunscreens, all chosen for their effectiveness and safety. Our mission is to help you achieve a radiant, healthy complexion with personalized skincare advice and exceptional service. Explore our wide range of products and let LJ Beauty House be your partner in enhancing your natural beauty.
    </div>
    </div>
</section>
<!-- Discount Section End -->

<!-- Services Section Begin -->
<section class="services spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="services__item">
                    <i class="mid"><img src="image/mobil.png" width="60px" alt=""></i>
                    <h6>Free Shipping</h6>
                    <p>For all oder over $99</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="services__item">
                <i class="mid"><img src="image/murah.png" width="50px" alt=""></i>
                    <h6>Money Back Guarantee</h6>
                    <p>If good have Problems</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="services__item">
                <i class="mid"><img src="image/Quality.png" width="50px" alt=""></i>
                    
                    <h6>Online Support 24/7</h6>
                    <p>Dedicated support</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <div class="services__item">
                <i class="mid"><img src="image/Cart.png" width="50px" alt=""></i>

                    <h6>Payment Secure</h6>
                    <p>100% secure payment</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Services Section End -->











@endsection



