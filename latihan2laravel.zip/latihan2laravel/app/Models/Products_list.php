<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Brand as brand;
use App\Models\Category as category;


class Products_list extends Model
{
    use HasFactory;

    protected $fillable = ['product_name', 'price', 'desc', 'url', 'product_pic', 'brand_id', 'category_id'];

    public function category()
    {
        return $this->belongsTo(category::class);
    }

    public function brand()
    {
        return $this->belongsTo(brand::class);
    }
}
