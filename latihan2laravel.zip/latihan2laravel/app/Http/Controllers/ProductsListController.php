<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

use App\Models\Products_list;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Carousel;
use GuzzleHttp\Client;
use Illuminate\Contracts\Cache\Store;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpParser\Node\Stmt\Catch_;

class ProductsListController extends Controller
{
    
    //* routing function

    public function route_product_list()
    {

        return view('admin_crud.product_list', [
            'products' => Products_list::all(), 
            'categories' => Category::all(),
            'brands' => Brand::all()
        ]);
    }

    public function route_create()
    {
        return view('admin_crud.create', [
            'product'=> false,
            'categories' => Category::all(),
            'brands' => Brand::all()
        ]);
    }
    
    public function route_edit($id)
    {
        return view('admin_crud.create', [
            'product' => Products_list::findOrFail($id),
            'categories' => Category::all(),
            'brands' => Brand::all()
        ]);
    }

    public function route_add_brand_category()
    {
        return view('admin_crud.test');
    }

    public function route_edit_brand_category($type, $id)
    {
        return view('admin_crud.edit_brand_category', [
            'temp' => ($type === 'brand') ? Brand::findOrFail($id) : Category::findOrFail($id),
            'title' => $type
        ]);
    }

    public function route_special_insert()
    {
        return view('admin_crud.special_insert');
    }



    //* Create, Update, and Delete functions

    public function add_brand_category(Request $request)
    {
        try{
            DB::beginTransaction();
            DB::commit();
            if($request->type === 'Brand'){
                $folder_name = 'public/' . $request->name;
                Storage::makeDirectory($folder_name);
                Brand::create([
                    'brand_name' => $request->name
                ]);
            }else{
                Category::create([
                    'category_name' => $request->name
                ]);
        }}
        catch(\Exception $e){
            DB::rollBack();
        }

        return back();
    }

    public function edit_brand_category(Request $request, $type, $id)
    {   
        try{
            DB::beginTransaction();
            DB::commit();

            if($type === 'brand'){
                $brand = Brand::findOrFail($id);
                Storage::disk('local')->move('public/' . $brand->brand_name, 'public/' . $request->name);
                Brand::findOrFail($id)->update([
                    'brand_name' => $request->name
            ]);
            }else{
                Category::findOrFail($id)->update([
                    'category_name' => $request->name
            ]);

        }}catch(\Exception $e){
            DB::beginTransaction();
            DB::commit();
        }
        
        return redirect('/admin');
    }


    public function delete_brand_category($type, $id)
    {
        try{
            DB::beginTransaction();
            DB::commit();

            if($type === 'brand'){
                
                Storage::deleteDirectory('public/' . Brand::findOrFail($id)->brand_name);
                
                Brand::destroy($id);

            }else{
                Category::destroy($id);
            }
        }catch(\Exception $e){
            DB::rollBack();

        }

        return back();
    }
 
        // * CRUD products data 

    public function store(Request $request)
    {
        // * validate some data before inserting
        try{
            DB::beginTransaction();
            DB::commit();

            $request->validate([
                'product_name' => 'required',
                'price' => 'required',
                'brand_id' => 'required',
                'category_id' => 'required',
                'product_pic' => 'required'
            ]);

            //     // * make path for pic before storing the picture

            // $file = $request->file('product_pic');
            // $path = $request->product_name . "-" . time() . '.' . $file->getClientOriginalExtension();

            //     // * insert the picture first

            // Storage::disk('local')->put("public/" . Brand::find($request->brand_id)->brand_name. "/" . $path, file_get_contents($file));

            Products_list::create([
                'product_name' => $request->product_name,
                'price' => $request->price,
                'brand_id' => $request->brand_id,
                'category_id' => $request->category_id,
                'product_pic' => $request->product_pic,
            ]);
        }catch(\Exception $e){
            DB::rollBack();
        }
        return back();
    }


    public function update(Request $request, $id)
    {
            // * validate some data before inserting

        $request->validate([
            'product_name' => 'required',
            'price' => 'required',
            'brand_id' => 'required',
            'category_id' => 'required',
            'product_pic' => '',

        ]);

        $product = Products_list::findOrFail($id);


        // // * if picture is exist in edit form 
        // $path = $product->product_name;
        
        // if($request->hasFile('product_pic'))
        // {
        //     $file = $request->file('product_pic');

        //     // * make path for pic before storing the picture
        //     $path =  $request->product_name . "-" . time() . '.' . $file->getClientOriginalExtension();


        //     // * delete and insert the picture first
        //     Storage::delete('public/' . $product->brand->brand_name . "/" . $product->product_pic);
            
        //     Storage::disk('local')->put("public/" . Brand::find($request->brand_id)->brand_name . "/" . $path, file_get_contents($file));
        // }
        //     // * updating time

        $product->update([
            'product_name' => $request->product_name,
            'price' => $request->price,
            'brand_id' => $request->brand_id,
            'category_id' => $request->category_id,
            'product_pic' => $request->product_pic,
        ]);

        return redirect('/admin');
    }

    
    public function delete($id)
    {   
            // * delete pic first
        
        $product = Products_list::find($id);
        Storage::delete('public/' . $product->brand->brand_name . '/' . $product->product_pic);

        Products_list::destroy($id);

        return back();
    }


    // * CRUD Category and Brand






    // * CRUD with Excel file

    public function accessing_excel(Request $request)
    {
        foreach(Brand::all() as $brand)
        {
            Storage::deleteDirectory('public/' . $brand->brand_name);
        }

        $file = IOFactory::load($request->file('excel_file'));

        $active_sheet = $file->getActiveSheet();

        for($i = 2; $i <= $active_sheet->getHighestRow() - 1; $i++)
        {
            
            $brand_name = $active_sheet->getCell('E'. $i)->getValue();
            $category_name = $active_sheet->getCell('F'. $i)->getValue();
            $url_excel = $active_sheet->getCell('G' . $i)->getValue();
            
            
            if(!$active_sheet->getCell('B' . $i)->getValue())
            {
                return redirect('/admin');
            }

            if(!$brand_name)
            {
                $brand_name = 'Lain-lain';
            }

            if(!$category_name)
            {
                $category_name = 'Lain-lain';
            }

            if(!Brand::where('brand_name', $brand_name)->exists())
            {
                Storage::makeDirectory('public/' . $brand_name);
                Brand::create([
                    'brand_name' => $brand_name
                ]);
            }

            if(!Category::where('category_name', $category_name)->exists())
            {
                Category::create([
                    'category_name' => $category_name
                ]);
            }

          

            // $img_path = '';

            // if($url_excel){

            //     try{
            //         $init = Http::timeout(600)->get($url_excel);

            //         if($init->successful())
            //         {
            //             $img_path = $active_sheet->getCell('B' . $i)->getValue() . '-' . time() . '.png';

                        
            //         }
            //     }catch(\Exception $error){
            //         Log::error("URL Client Error: " . $error->getMessage());
            //         $img_path = $url_excel;
            //     }


               
            // }

            // Storage::disk('local')->put("public/" . $brand_name . '/' . $img_path, file_get_contents($url_excel));
            Products_list::create([
                'product_name' => $active_sheet->getCell('B' . $i)->getValue(),
                'price' => $active_sheet->getCell('D'.$i)->getValue(),  
                'brand_id' => Brand::where('brand_name', $brand_name)->first()->id,
                'category_id' => Category::where('category_name', $category_name)->first()->id,
                'product_pic' => $url_excel,
                // 'url' => $url_excel 
            ]);

            
    }
    return redirect('/admin');
    }

}
