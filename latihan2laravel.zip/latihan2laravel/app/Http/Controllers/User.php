<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Products_list;
use App\Models\Brand;
use App\Models\Category;


class User extends Controller
{
    public function route_home()
    {

        return view('customer_ui.index',[
            'title' => 'Home',
            'products' => Products_list::where('product_pic', 'like', '%_%')->inRandomOrder()->limit(8)->get()
        ]);
    }

    public function get_search_data(Request $request)
    {
        $search = $request->query('search');

        if(!$search)
        {
            return response()->json([
                'products' => Products_list::all()
            ]);
        }

        $products = Products_list::where('product_name', 'like', '%' . $search . '%')->get();

        return response()->json([
            'products' => $products
        ]);
    }


    public function route_catalogue(Request $request)
    {

        if($request->query('brand')){
            return view('customer_ui.shop',[
                'title' => 'Catalogue',
                'brands' => Brand::all(),
                'categories' => Category::all(),
                'products' => Products_list::where('brand_id', $request->query('brand'))->paginate(12)
            ]);
        }

        if($request->query('category')){
            return view('customer_ui.shop',[
                'title' => 'Catalogue',
                'brands' => Brand::all(),
                'categories' => Category::all(),
                'products' => Products_list::where('category_id', $request->query('category'))->paginate(12)
            ]);
        }     
        
        if($request->search_input){
            return view('customer_ui.shop',[
                'title' => 'Catalogue',
                'brands' => Brand::all(),
                'categories' => Category::all(),
                'products' => Products_list::where('product_name', 'like', '%' . $request->search_input . '%')->paginate(12)
            ]);
        }     

        return view('customer_ui.shop', [
            'title' => 'Catalogue',
            'brands' => Brand::all(),
            'categories' => Category::all(),
            'products' => Products_list::paginate(12)
        ]);
    }

    public function route_cart()
    {
        return view('customer_ui.shop_cart', [
            'title' => 'Cart'
        ]);
    }

    public function route_contact()
    {
        return view('customer_ui.contact', [
            'title' => 'Contact Us'
        ]);
    }

    public function get_data()
    {
        return response()->json([
            'products' => Products_list::all()
        ]);
    }

    // * di bawah untuk ui yang baru



    public function route_c_catalogue()
    {
        return view('customer_ui.shop',[
            'title' => 'Shop',
            'products' => Products_list::all(),
            'brands' => Brand::all(),
            'categories' => Category::all()
        ]);
    }

}
