<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products_lists', function (Blueprint $table) {
           
            // * it own attribute
            $table->id();
            $table->string('product_name')->unique();
            $table->integer('price');
            $table->string('product_pic', 2048)->nullable();
            // $table->string('url', 2048)->nullable();
            
            // * foreign key attribute
            $table->bigInteger('brand_id')->unsigned();
            $table->foreign('brand_id')->references('id')->on('brands')->onDelete('cascade');

            $table->bigInteger('category_id')->unsigned();
            $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');

            // * attribute from Laravel
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */

    public function down(): void
    {
        Schema::dropIfExists('products_lists');
    }
};
